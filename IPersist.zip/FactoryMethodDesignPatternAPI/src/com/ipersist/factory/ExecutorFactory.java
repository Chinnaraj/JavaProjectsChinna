package com.ipersist.factory;

import com.ipersist.entity.Person;
import com.ipersist.executor.PersonExecutor;
import com.ipersist.executors.QueryExecutor;
import com.ipersist.executors.factory.AbstractQueryExecutorFactory;

public class ExecutorFactory extends AbstractQueryExecutorFactory {

	@Override
	protected QueryExecutor<?> createQueryExecutor(String queryExecutorName) {
		QueryExecutor<Person> executor = null;
		
		if(queryExecutorName.equals("person")) {
			executor = new PersonExecutor("person-config.xml");
		}
		
		return executor;
	}
	
}

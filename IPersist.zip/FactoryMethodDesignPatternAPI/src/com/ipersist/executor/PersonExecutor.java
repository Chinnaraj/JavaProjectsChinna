package com.ipersist.executor;

import java.sql.ResultSet;

import com.ipersist.entity.Person;
import com.ipersist.executors.QueryExecutor;

public class PersonExecutor extends QueryExecutor<Person> {
	

	public PersonExecutor(String resourceFile) {
		super(resourceFile);
	}

	@Override
	public Person extract(ResultSet rs) throws Exception {
		Person person = null;
		rs.next();
		person = new Person(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5));
		return person;
	}
	
}

package com.ipersist.test;

import com.ipersist.entity.Person;
import com.ipersist.executors.QueryExecutor;
import com.ipersist.factory.ExecutorFactory;

public class Test {
	public static void main(String[] args) {
		ExecutorFactory factory = new ExecutorFactory();
		QueryExecutor<Person> executor = (QueryExecutor<Person>) factory.newQueryExecutor("person");
		Person person = executor.execute();
		System.out.println(person);
		
	}
}

package com.ipersist.entity;

import java.sql.Date;

public class Person {
	private int personId;
	private String personName;
	private String gender;
	private Date dob;
	private String address;

	public Person() {

	}

	public Person(int personId, String personName, String gender, Date dob, String address) {
		super();
		this.personId = personId;
		this.personName = personName;
		this.gender = gender;
		this.dob = dob;
		this.address = address;
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName + ", gender=" + gender + ", dob=" + dob
				+ ", address=" + address + "]";
	}

}

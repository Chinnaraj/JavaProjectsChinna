package com.ipersist.executors.factory;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ipersist.config.Config;
import com.ipersist.executors.QueryExecutor;
import com.ipersist.executors.exceptions.IPersistSQLException;
import com.ipersist.executors.exceptions.InvalidConfigException;

public abstract class AbstractQueryExecutorFactory {
	public QueryExecutor<?> newQueryExecutor(String queryExecutorName) {
		QueryExecutor<?> queryExecutor = null;
		Config config = null;
		queryExecutor = createQueryExecutor(queryExecutorName);
		config = parseConfig(queryExecutor.getResourceFile());
		Connection connection = createConnection(config);
		//First Step
		queryExecutor.setConfig(config);
		//Second Step
		queryExecutor.setConnection(connection);
		//Third Step
		queryExecutor.setQuery(config.getQuery());
		
		return queryExecutor;
	}
	protected abstract QueryExecutor<?> createQueryExecutor(String queryExecutor);
	private Config parseConfig(String resourceFile) {
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		Document document = null;
		Config config = null;
		try {
			config = new Config();
			factory = DocumentBuilderFactory.newInstance();
			factory.setIgnoringElementContentWhitespace(true);
			builder = factory.newDocumentBuilder();
			document = builder.parse(this.getClass().getClassLoader().getResourceAsStream(resourceFile));
			NodeList list = document.getFirstChild().getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i).getNextSibling();
				if (node != null) {
					String value = node.getTextContent();
					if (node.getNodeName().equals("driver-name")) {
						config.setDriverName(value);
					} else if (node.getNodeName().equals("url")) {
						config.setUrl(value);
					} else if (node.getNodeName().equals("username")) {
						config.setUserName(value);
					} else if (node.getNodeName().equals("password")) {
						config.setPassword(value);
					} else if (node.getNodeName().equals("query")) {
						config.setQuery(value);
					}
				}
			}
		} catch (Exception e) {
			throw new InvalidConfigException("Unable To Parse The Config.xml" + resourceFile, e);
		}
		return config;
	}
	private Connection createConnection(Config config) {
		Connection connection = null;
		try {
			Class.forName(config.getDriverName());
			connection = DriverManager.getConnection(config.getUrl(), config.getUserName(), config.getPassword());
		} catch (Exception e) {
			throw new IPersistSQLException("Unable To Create Connection", e);
		}
		return connection;
	}
}

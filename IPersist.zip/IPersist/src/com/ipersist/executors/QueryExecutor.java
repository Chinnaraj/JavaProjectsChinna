package com.ipersist.executors;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ipersist.config.Config;
import com.ipersist.executors.exceptions.IPersistSQLException;

public abstract class QueryExecutor<T> {
	private Config config;
	private String query;
	private Connection connection;
	private String resourceFile;
	public QueryExecutor(String resourceFile) {
		this.setResourceFile(resourceFile);
	}
	public T execute() {
		T rtrn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName(config.getDriverName());
			connection = DriverManager.getConnection(config.getUrl(), config.getUserName(), config.getPassword());
			pstmt = connection.prepareStatement(query);
			rs = pstmt.executeQuery();
			rtrn = extract(rs);
		} catch (Exception e) {
			throw new IPersistSQLException("Unable To Fetch The Data", e);
		} finally {
			if(connection != null) {
				if(pstmt != null) {
					if(rs != null) {
						try {
							rs.close();
						} catch (SQLException e) {
							throw new IPersistSQLException("Unable To Close Resultset", e);
						}
					}
					try {
						pstmt.close();
					} catch (SQLException e) {
						throw new IPersistSQLException("Unable To Close PreparedStatement", e);
					}
				}
				try {
					connection.close();
				} catch (SQLException e) {
					throw new IPersistSQLException("Unable To Close Connection", e);
				}
			}
		}
		
		return rtrn;
	}
	public abstract T extract(ResultSet rs) throws Exception;
	public Config getConfig() {
		return config;
	}
	public void setConfig(Config config) {
		this.config = config;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public Connection getConnection() {
		return connection;
	}
	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public String getResourceFile() {
		return resourceFile;
	}
	public void setResourceFile(String resourceFile) {
		this.resourceFile = resourceFile;
	}
	
}

package com.ipersist.executors.exceptions;

public class IPersistSQLException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public IPersistSQLException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
}
